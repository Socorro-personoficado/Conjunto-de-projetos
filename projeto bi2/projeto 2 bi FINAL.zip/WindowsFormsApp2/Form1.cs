﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //vairiaveis globais
        int[] Mouse_Cord = new int[4];
        List<Point> p = new List<Point>();
        List<Point> pCarregado = new List<Point>();
        float[] salvarEstilo;
        //point é do e do MouseEventArgs pega cordenada do mouse direto pelo e.Location so que vem com os X e Y junto usa cord.X/Y para pegaro respequitivo
        int forma = 1;
        int maxPontos = 5;
        string Salvar;
        Pen canetaCarregada;
        bool desenharCarregado = false;
        int ladosCarregados = 0;



        private void button1_Click(object sender, EventArgs e)
        {

        }

       

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }



        void DesenharPoligono(PaintEventArgs e, Pen caneta, int nLados)
        {
            if (p.Count != nLados)
                return;
            // Desenhar os lados
            Salvar = "Coordenadas pontos (X1, Y1, X2, Y2...):\n";
            for (int i = 0; i < nLados; i++)
            {
                int j = (i + 1) % nLados; // Garante que o último ponto se conecta ao primeiro
                desenhar(e, caneta, p[i].X, p[i].Y, p[j].X, p[j].Y);
                Salvar = Salvar + p[i].X + "\n" + p[i].Y + "\n";
            };
            
            string estiloTexto = "";
            foreach (float valor in salvarEstilo)
            {
                estiloTexto += valor.ToString() + ", ";
            }
            if (estiloTexto.Length > 2)
                estiloTexto = estiloTexto.Substring(0, estiloTexto.Length - 2);

            Salvar += "Cores: \n" + "R: \n" + caneta.Color.R + "\n" + "G: \n" + caneta.Color.G + "\n" + "B: \n" + caneta.Color.B + "\n";

            Salvar += "Estilo: \n" + estiloTexto + "\n";

            Salvar += "Espessura: \n" + caneta.Width.ToString();
            p.Clear();
        }

        void DesenharRetangulo(PaintEventArgs e, Pen caneta)
        {
            if (p.Count != 2)
                return;

            // Dois pontos extremos da diagonal
            Point p1 = p[0];
            Point p2 = p[1];

            // Calcula coordenadas e tamanho do retângulo
            int xMin = Math.Min(p1.X, p2.X);
            int xMax = Math.Max(p1.X, p2.X);
            int yMin = Math.Min(p1.Y, p2.Y);
            int yMax = Math.Max(p1.Y, p2.Y);

            Point pA = new Point(xMin, yMin); // canto superior esquerdo
            Point pB = new Point(xMax, yMin); // canto superior direito
            Point pC = new Point(xMax, yMax); // canto inferior direito
            Point pD = new Point(xMin, yMax); // canto inferior esquerdo

            // Desenha as 4 linhas do quadrado manualmente
            desenhar(e, caneta, pA.X, pA.Y, pB.X, pB.Y); // topo
            desenhar(e, caneta, pB.X, pB.Y, pC.X, pC.Y); // direita
            desenhar(e, caneta, pC.X, pC.Y, pD.X, pD.Y); // base
            desenhar(e, caneta, pD.X, pD.Y, pA.X, pA.Y); // esquerda

            // Salvar os dados
            Salvar = $"Coordenadas pontos (X1, Y1, X2, Y2...):\n{pA.X}\n{pA.Y}\n{pB.X}\n{pB.Y}\n{pC.X}\n{ pC.Y}\n{ pD.X}\n{ pD.Y}\n";

            string estiloTexto = "";

            foreach (float valor in salvarEstilo)
                estiloTexto += valor.ToString() + ", ";

            if (estiloTexto.Length > 2)
                estiloTexto = estiloTexto.Substring(0, estiloTexto.Length - 2);

            Salvar += $"Cores: \nR: \n{caneta.Color.R}\nG: \n{caneta.Color.G}\nB: \n{caneta.Color.B}\n";
            Salvar += $"Estilo: \n{estiloTexto}\n";
            Salvar += $"Espessura: \n{caneta.Width}";

            p.Clear();
        }

        void DesenhoCarregado(PaintEventArgs e, Pen caneta, int nLados)
        {
            // Desenhar os lados
            for (int i = 0; i < nLados; i++)
            {
                int j = (i + 1) % nLados; // Garante que o último ponto se conecta ao primeiro
                desenhar(e, caneta, pCarregado[i].X, pCarregado[i].Y, pCarregado[j].X, pCarregado[j].Y);
            };

            string estiloTexto = "";
            foreach (float valor in salvarEstilo)
            {
                estiloTexto += valor.ToString() + ", ";
            }
            if (estiloTexto.Length > 2)
                estiloTexto = estiloTexto.Substring(0, estiloTexto.Length - 2);
        }


        public Pen estilo_linha(float[] estilo, Color cor, int espessura)
        {
            Pen caneta = new Pen(cor, espessura);
            caneta.DashPattern = estilo;
            return caneta;
        }



        public Color cor()
        {
            Color cor = new Color();
            cor = button1.BackColor;
            return cor;
        }



        public int esp()
        {
            int esp = Int32.Parse(textBox1.Text);
            return esp;
        }



        public float[] dash()
        {
            float[] estilo;

            switch (comboBox1.Text)
            {
                case "Linha Tracejada":
                    estilo = new float[] { 5, 2 };
                    break;
                case "Linha Traço Ponto":
                    estilo = new float[] { 5, 2, 1, 2 };
                    break;
                case "Linha Traço Dois Pontos":
                    estilo = new float[] { 5, 2, 1, 2, 1, 2 };
                    break;
                case "Linha Pontilhada":
                    estilo = new float[] { 1, 2 };
                    break;
                default: // "Nenhuma" ou "Linha Sólida"
                    estilo = new float[] { 1 };
                    break;
            }

            salvarEstilo = estilo;
            return estilo;
        }

        public void desenhar(PaintEventArgs e, Pen caneta, int x1, int y1, int x2, int y2)
        {
            e.Graphics.DrawLine(caneta, x1, y1, x2, y2);
        }



        void AdicionarPonto(Point novoPonto)
        {
            if (p.Count >= maxPontos)
            {
                // Remove o ponto mais antigo (primeiro da lista)
                p.RemoveAt(0);
            }

            // Adiciona o novo ponto ao final
            p.Add(novoPonto);
        }



        // tem que ser o do painel pq o painel vai cobrir o form todo dai o click conta que foi no painel
        private void panel1_MouseClick(object sender, MouseEventArgs e)
        {
            AdicionarPonto(e.Location);

            if (p.Count == maxPontos)
            {
                panel1.Invalidate(); // força o Paint
            }

            // Atualizar a label com todos os pontos (seguro)
            StringBuilder sb = new StringBuilder();
            foreach (var ponto in p)
            {
                sb.AppendLine(ponto.X + ", " + ponto.Y);
            }
        }



        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            if (desenharCarregado)
            {
                DesenhoCarregado(e, canetaCarregada, ladosCarregados);
                desenharCarregado = false; // para desenhar só uma vez
            }
            Pen caneta = estilo_linha(dash(), cor(), esp());
            switch (forma)
            {
                case 1: // Linha
                    DesenharPoligono(e, caneta, 2); break;

                case 2: // Quadrado
                    DesenharRetangulo(e, caneta); break;

                case 3: // Triângulo
                    DesenharPoligono(e, caneta, 3); break;

                case 4: // Losango
                    DesenharPoligono(e, caneta, 4); break;

                case 5: // Pentágono
                    DesenharPoligono(e, caneta, 5); break;
            }
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(0, 0, 0);
        }

        private void button21_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(255, 255, 255);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(128, 128, 128);
        }

        private void button20_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(192, 192, 192);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(128, 0, 0);
        }

        private void button19_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(165, 42, 42);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(255, 0, 0);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(255, 182, 193);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(255, 165, 0);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(255, 255, 0);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(255, 255, 153);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(255, 255, 204);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(0, 128, 0);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(144, 238, 144);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(0, 128, 128);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(173, 255, 255);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(0, 0, 139);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(173, 216, 230);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(255, 0, 255);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(255, 192, 203);
        }

        private void button22_Click(object sender, EventArgs e) // Triângulo
        {
            forma = 3;
            maxPontos = 3;
            p.Clear();
        }

        private void button23_Click(object sender, EventArgs e) // Quadrado
        {
            forma = 2;
            maxPontos = 2;
            p.Clear();
        }

        private void button24_Click(object sender, EventArgs e) // Linha
        {
            forma = 1;
            maxPontos = 2;
            p.Clear();
        }

        private void button25_Click(object sender, EventArgs e) // Pentágono
        {
            forma = 5;
            maxPontos = 5;
            p.Clear();
        }

        private void button26_Click(object sender, EventArgs e) // Losango
        {
            forma = 4;
            maxPontos = 4;
            p.Clear();
        }

        private void buttonSave_Click(object sender, EventArgs e) //salvar
        {
            File.WriteAllText(@"C:\Arquivos\dados.dat", Salvar);
        }

        private void button27_Click(object sender, EventArgs e)
        {
            pCarregado.Clear();
            string[] linhas = File.ReadAllLines(@"C:\Arquivos\dados.dat");

            int formaCarregar = linhas.Length - 12;

            // Agora pegamos os índices baseados em formaCarregar
            int r = Int32.Parse(linhas[formaCarregar + 3]);
            int g = Int32.Parse(linhas[formaCarregar + 5]);
            int b = Int32.Parse(linhas[formaCarregar + 7]);
            int indiceEstilo = formaCarregar + 9;
            string[] partes = linhas[indiceEstilo].Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
            float[] resultado = new float[partes.Length];

            for (int i = 0; i < partes.Length; i++)
                resultado[i] = float.Parse(partes[i]);

            int espessura = Int32.Parse(linhas[formaCarregar + 11]);
            canetaCarregada = estilo_linha(resultado, Color.FromArgb(r, g, b), espessura);
            ladosCarregados = formaCarregar / 2; // cada ponto tem 2 linhas (X e Y)
            desenharCarregado = true;
            for (int i = 1; i <= formaCarregar-1; i += 2)
            {
                int x = Int32.Parse(linhas[i].Trim());
                int y = Int32.Parse(linhas[i + 1].Trim());
                pCarregado.Add(new Point(x, y));
            }
            panel1.Invalidate();
        }
    }
}
